const leaseController = {
  getAll: async (req, res) => { /* ... */ },
  getById: async (req, res) => { /* ... */ },
  create: async (req, res) => { /* ... */ },
  update: async (req, res) => { /* ... */ },
  delete: async (req, res) => { /* ... */ }
};

module.exports = leaseController;