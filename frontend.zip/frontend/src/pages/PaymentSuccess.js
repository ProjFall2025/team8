export default function PaymentSuccess() {
  return (
    <div>
      <h2> Payment Successful!</h2>
      <p>Thank you for your payment. Your transaction has been processed.</p>
    </div>
  );
}