export default function MaintenancePage() {
  return <h2>🛠️ Maintenance Requests Coming Soon</h2>;
}