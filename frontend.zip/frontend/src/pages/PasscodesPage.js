export default function PasscodesPage() {
  return <h2>🔐 Smart Passcodes Coming Soon</h2>;
}