export default function TenantsPage() {
  return <h2>👥 Tenant List Coming Soon</h2>;
}