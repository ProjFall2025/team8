import React from 'react';

const TenantDashboard = () => {
  return (
    <div>
      <h2>Welcome, Tenant!</h2>
      <p>Your dashboard is ready.</p>
    </div>
  );
};

export default TenantDashboard;