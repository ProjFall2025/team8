export default function PropertiesPage() {
  return <h2>🏢 Property Management Coming Soon</h2>;
}